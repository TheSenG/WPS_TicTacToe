﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S06_Grid
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool player1 = true;

        public MainWindow()
        {
            InitializeComponent();

            UpdateTurnUI();
        }

        private void PlayerMove(object sender, RoutedEventArgs e)
        {
            if (sender is Button button)
            {
                //EL JUGADOR 1 PONE UN COLOR ROJIZO
                if (player1)
                {
                    button.Background = Brushes.IndianRed;
                    button.Content = "X";
                }
                //EL JUGADOR 2 PONE UN COLOR AZULADO
                else
                {
                    button.Background = Brushes.SkyBlue;
                    button.Content = "O";
                }
                //CAMBIAMOS EL TURNO DEL PLAYER
                player1 = !player1;
                //ACTUALIZAMOS LA UI
                UpdateTurnUI();
            }
        }

        private void UpdateTurnUI()
        {
            //CAMBIAMOS UI DE TURNO
            if (player1)
            {
                p1Txt.Background = Brushes.LightGray;
                p2Txt.Background = Brushes.White;
            }
            else
            {
                p1Txt.Background = Brushes.White;
                p2Txt.Background = Brushes.LightGray;
            }
        }

        private void RestartApp(object sender, RoutedEventArgs e)
        {
            //RESETEAMOS TODOS LOS COLORES
            foreach (var button in playGrid.Children.OfType<Button>())
            {
                button.Background = Brushes.White;
                button.Content= "";
            }
            //EMPIEZA EL PLAYER 1 DE NUEVO
            player1 = true;
            //ACTUALIZAMOS TURNOS
            UpdateTurnUI();

            MessageBox.Show("GAME RESTARTED");

        }
    }
}
